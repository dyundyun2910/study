﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PngToBmp24BitUi
{
    public partial class PngToBmp24Form : Form
    {
        public PngToBmp24Form()
        {
            InitializeComponent();
        }

        private void buttonFolder_Click(object sender, EventArgs e)
        {
            SetFoloderPath();
        }

        private void SetFoloderPath()
        {
            FolderBrowserDialog dlg = new FolderBrowserDialog();

            dlg.Description = "フォルダを指定してください。";
            dlg.RootFolder = Environment.SpecialFolder.Desktop;
            dlg.SelectedPath = @"C:\Windows";
            dlg.ShowNewFolderButton = true;

            if (dlg.ShowDialog(this) == DialogResult.OK)
            {
                textBoxFolder.Text = dlg.SelectedPath;
            }
        }

        private void buttonExecute_Click(object sender, EventArgs e)
        {
            string exePath = GetExePath();
            string option = GetOptionString();
            System.Diagnostics.Process.Start(exePath, option);
        }

        private static string GetExePath()
        {
            return System.IO.Directory.GetCurrentDirectory() + @"/python/main.exe";
        }

        private string GetOptionString()
        {
            string option = textBoxFolder.Text;
            option += " ";
            option += GetRGBString(pictureBox1);
            option += " ";
            option += GetRGBString(pictureBox2);
            return option;
        }

        private string GetRGBString(PictureBox pictureBox)
        {
            return pictureBox.BackColor.R.ToString()
                + ","
                + pictureBox.BackColor.G
                + ","
                + pictureBox.BackColor.B;
        }

        private void buttonBackColorSelect_Click(object sender, EventArgs e)
        {
            pictureBox1.BackColor = GetColorByColorDialog(pictureBox1.BackColor);
        }

        private void buttonTransColorSelect_Click(object sender, EventArgs e)
        {
            pictureBox2.BackColor = GetColorByColorDialog(pictureBox2.BackColor);
        }

        private Color GetColorByColorDialog(Color defaultColor)
        {
            ColorDialog cd = new ColorDialog();

            cd.Color = defaultColor;
            cd.AllowFullOpen = true;
            cd.SolidColorOnly = false;

            cd.ShowDialog();
            return cd.Color;
        }
    }
}
